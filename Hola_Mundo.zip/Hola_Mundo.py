var= "Hola Mundo!"

print(var)